﻿using System;

namespace StandardLib
{
    public class Class1
    {
    }
}
